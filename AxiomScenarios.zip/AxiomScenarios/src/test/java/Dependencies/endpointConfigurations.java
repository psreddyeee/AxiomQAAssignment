package Dependencies;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.testng.Assert;

public class endpointConfigurations {

	public static String getURI(String uri) {
		String urlInfo = null;
		try {
			Properties prop = new Properties();
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + File.separator + "EndPointURI.properties");
			prop.load(fis);
			urlInfo = prop.getProperty(uri);
		} catch (Exception e) {
			Assert.fail("Error while retrieving the property file" + e);
		}
		return urlInfo;
	}

}

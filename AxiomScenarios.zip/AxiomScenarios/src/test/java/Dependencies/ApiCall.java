package Dependencies;
import static io.restassured.RestAssured.given;

import io.restassured.response.Response;

public class ApiCall {
	public static Response response;
	
	public static Response getcall(String url)
	{
		response = given().log().all().when().get(url) 
		.then().log().all().assertThat().statusCode(200).statusLine("HTTP/1.1 200 OK")
		.extract().response(); 
		
		return response;
	}
	

}

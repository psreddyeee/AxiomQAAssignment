package AxiomTest.AxiomScenarios;

import static io.restassured.RestAssured.given;

import io.restassured.response.Response;

public class getMethodCallTest {

	public static Response getAPICall(String uri) {
		Response res = given().log().all().when().get(uri).then().log().all().assertThat().statusCode(200).extract()
				.response();

		return res;
	}

}

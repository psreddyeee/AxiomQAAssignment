package AxiomTest.AxiomScenarios;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Scn2Test {
	@Test
	public void Scenario2() {
		RestAssured.baseURI = Dependencies.endpointConfigurations.getURI("getEmplyeeinfoURI");
		String employeeId = Dependencies.CSVReader.getemploeeIDfromcsv(4);
		Response res = getMethodCallTest.getAPICall("/api/v1/employee/" + employeeId);
		JsonPath js = new JsonPath(res.asString());
		String message = js.getString("message");
		Assert.assertEquals(message, "Successfully! Record has been fetched.");
		
		String filename = null;
		String path = "EmployeeResponseSchema.json";
		try {

			filename = new String(Files.readAllBytes(Paths.get(path)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		res.then().assertThat().body(matchesJsonSchema(filename));
	}
}

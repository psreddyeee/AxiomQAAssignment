package AxiomTest.AxiomScenarios;

import org.testng.Assert;
import org.testng.annotations.Test;

import Dependencies.endpointConfigurations;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Scn1Test {
	@Test
	public void scenarios1() {

		RestAssured.baseURI = endpointConfigurations.getURI("getEmplyeeinfoURI");
		Response rawResponse = getMethodCallTest.getAPICall("/api/v1/employees");
		JsonPath js = new JsonPath(rawResponse.asString());
		int count = js.getInt("data.size()");

		for (int i = 0; i < count; i++) {
			String printvalue = js.getString("data[" + i + "].profile_image");
			Assert.assertEquals("", printvalue);
		}
	}
}
